select
    borough,
    complaint_type,
    count(*) as row_count
from {{ ref('fct_borough_complaint_mix') }}
group by borough, complaint_type
having count(*) > 1
