select
    complaint_type,
    descriptor,
    descriptor_2,
    count(*) as row_count
from {{ ref('dim_complaint_type') }}
group by complaint_type, descriptor, descriptor_2
having count(*) > 1
