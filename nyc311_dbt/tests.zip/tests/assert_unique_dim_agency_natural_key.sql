select
    agency,
    agency_name,
    count(*) as row_count
from {{ ref('dim_agency') }}
group by agency, agency_name
having count(*) > 1
